package main;

import java.sql.SQLException;

public class Run {
    static Methods dbm = new Methods();

    public static void main(String[] args){
        dbm.menu();
    }
}
